﻿using System;
using System.Collections.Generic;
using System.Text;

namespace winamr.Enums
{
    public enum MenuItemType
    {
        Browse,
        About,
        DeviceGroups,
        Pies,
        ShoppingCart,
        Contact,
        Logout,
        Profile
    }
}
