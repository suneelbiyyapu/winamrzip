﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using winamr.Contracts.Services.General;
using winamr.Models;
using Xamarin.Forms;
using ZXing.Net.Mobile.Forms;

namespace winamr.ViewModels
{
    public class DeviceViewModel : BaseViewModel
    {
        ZXingScannerPage scanPage;

        #region Properties

        private DeviceGroup _devices;

        public DeviceGroup Devices
        {
            get => _devices;
            set
            {
                _devices = value;
                OnPropertyChanged();
            }
        }

        public bool isCreateDeviceVisible;
        public bool IsCreateDeviceVisible
        {
            get => isCreateDeviceVisible;
            set
            {
                isCreateDeviceVisible = value;
                OnPropertyChanged(nameof(IsCreateDeviceVisible));
            }
        }

        public string deviceName;
        public string DeviceName
        {
            get => deviceName;
            set
            {
                deviceName = value;
                OnPropertyChanged(nameof(DeviceName));
            }
        }

        public string scanData;
        public string ScanData
        {
            get => scanData;
            set
            {
                scanData = value;
                OnPropertyChanged(nameof(ScanData));
            }
        }

        #endregion

        #region Constructor

        public DeviceViewModel(IConnectionService connectionService,
            INavigationService navigationService,
            IDialogService dialogService) : base(connectionService, navigationService, dialogService)
        {
            // handle this

            this.IsCreateDeviceVisible = false;
        }

        #endregion

        #region Commands

        /*
        public ICommand PieTappedCommand => new Command<Pie>(OnPieTapped);
        public ICommand AddToCartCommand => new Command<Pie>(OnAddToCart);
        */

        public ICommand AddDeviceCommand => new Command(OnAddDeviceTapped);
        public ICommand SaveCommand => new Command(OnSaveDeviceTapped);
        public ICommand CancelCommand => new Command(OnCancelDeviceTapped);
        public ICommand RemoveDeviceCommand => new Command(OnRemoveDeviceTapped);

        #endregion

        #region Virtual Method InitializeAsync

        public override async Task InitializeAsync(object data)
        {
            // PiesOfTheWeek = (await _catalogDataService.GetPiesOfTheWeekAsync()).ToObservableCollection();
            Devices = (DeviceGroup)data;
            //return Task.FromResult(false);
        }

        #endregion

        #region Private Methods

        private async void OnAddDeviceTapped(object addDeviceTappedEventArgs)
        {
            var deviceText = string.Empty;

            scanPage = new ZXingScannerPage();
            scanPage.OnScanResult += (result) => {
                scanPage.IsScanning = false;

                Xamarin.Forms.Device.BeginInvokeOnMainThread(() => {
                    Application.Current.MainPage.Navigation.PopModalAsync();
                    ScanData = result.Text;
                    this.IsCreateDeviceVisible = true;
                    //Application.Current.MainPage.DisplayAlert("Scanned Barcode", result.Text, "OK");
                });
            };

            await Application.Current.MainPage.Navigation.PushModalAsync(scanPage);
        }

        private void OnSaveDeviceTapped(object saveDeviceTappedEventArgs)
        {
            var deviceScannedData = ScanData;

            Devices.Devices.Add(new Models.Device
            {
                DeviceId = Devices.Devices.Count + 1,
                DeviceName = DeviceName,
                DeviceType = "Type1",
                IsDeviceEnable = true
            });

            this.IsCreateDeviceVisible = false;

            this.DeviceName = string.Empty;
        }

        private void OnCancelDeviceTapped(object cancelDeviceTappedEventArgs)
        {
            this.IsCreateDeviceVisible = false;
            this.DeviceName = string.Empty;
        }

        private void OnRemoveDeviceTapped(object removeDeviceGroupTappedEventArgs)
        {
            Devices.Devices.Remove(removeDeviceGroupTappedEventArgs as Models.Device);
        }

        #endregion
    }
}
