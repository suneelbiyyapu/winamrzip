# winamr
sample project

You can see screenshots in Issues tab.
